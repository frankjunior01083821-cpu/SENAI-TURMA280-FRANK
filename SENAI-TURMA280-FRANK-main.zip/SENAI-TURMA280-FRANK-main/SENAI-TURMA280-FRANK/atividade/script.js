function cadastrar(){
    const usuario = document .getElementById('usuario').value
    const senha = document .getElementById('senha').value
    const confirmarsenha = document .getElementById('confirmarSenha')
}